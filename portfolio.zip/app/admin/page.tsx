"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function AdminDashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [content, setContent] = useState({
    about: "",
    skills: "",
    experience: "",
  })

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/admin/login")
    }
  }, [status, router])

  useEffect(() => {
    // Fetch current content
    const fetchContent = async () => {
      const res = await fetch("/api/content")
      const data = await res.json()
      setContent(data)
    }
    fetchContent()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const res = await fetch("/api/content", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(content),
    })
    if (res.ok) {
      alert("Content updated successfully")
    } else {
      alert("Failed to update content")
    }
  }

  if (status === "loading") {
    return <div>Loading...</div>
  }

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle>Admin Dashboard</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="about" className="text-sm font-medium">
                About
              </label>
              <Textarea
                id="about"
                value={content.about}
                onChange={(e) => setContent({ ...content, about: e.target.value })}
                rows={5}
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="skills" className="text-sm font-medium">
                Skills
              </label>
              <Textarea
                id="skills"
                value={content.skills}
                onChange={(e) => setContent({ ...content, skills: e.target.value })}
                rows={5}
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="experience" className="text-sm font-medium">
                Experience
              </label>
              <Textarea
                id="experience"
                value={content.experience}
                onChange={(e) => setContent({ ...content, experience: e.target.value })}
                rows={5}
              />
            </div>
            <Button type="submit">Update Content</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

