import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { db } from "@/db"
import { siteContent } from "@/db/schema"
import { eq } from "drizzle-orm"

export async function GET() {
  const content = await db.select().from(siteContent)
  const contentObject = content.reduce(
    (acc, item) => {
      acc[item.key] = item.content
      return acc
    },
    {} as Record<string, string>,
  )
  return NextResponse.json(contentObject)
}

export async function POST(req: Request) {
  const session = await getServerSession()
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const body = await req.json()
  const updates = Object.entries(body).map(async ([key, content]) => {
    const existingContent = await db.select().from(siteContent).where(eq(siteContent.key, key)).limit(1)
    if (existingContent.length > 0) {
      return db
        .update(siteContent)
        .set({ content: content as string })
        .where(eq(siteContent.key, key))
    } else {
      return db.insert(siteContent).values({ key, content: content as string })
    }
  })

  await Promise.all(updates)

  return NextResponse.json({ message: "Content updated successfully" })
}

