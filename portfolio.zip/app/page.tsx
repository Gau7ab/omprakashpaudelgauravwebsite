import { db } from "@/db"
import { siteContent } from "@/db/schema"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function Home() {
  const content = await db.select().from(siteContent)
  const contentObject = content.reduce(
    (acc, item) => {
      acc[item.key] = item.content
      return acc
    },
    {} as Record<string, string>,
  )

  return (
    <div className="flex flex-col items-center gap-8 py-12 md:py-24">
      <div className="relative h-48 w-48 overflow-hidden rounded-full border-4 border-primary">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ABC4.jpg-6Od2QDYDYJ9ovFU3R9jUeoNVtLmode.jpeg"
          alt="Profile picture"
          fill
          className="object-cover"
          priority
        />
      </div>

      <div className="text-center">
        <h1 className="text-4xl font-bold">Om Prakash Paudel (Gaurav)</h1>
        <p className="mt-4 text-xl text-muted-foreground">Marketing Professional & Trek Enthusiast</p>
      </div>

      <div className="mt-4 space-y-2 text-center">
        <p className="text-lg">{contentObject.about}</p>
      </div>

      <div className="mt-8 flex gap-4">
        <Button asChild>
          <Link href="/portfolio">View Portfolio</Link>
        </Button>
        <Button variant="outline" asChild>
          <Link href="/contact">Contact Me</Link>
        </Button>
      </div>
    </div>
  )
}

