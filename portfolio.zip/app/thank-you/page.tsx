import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function ThankYou() {
  return (
    <div className="container mx-auto flex h-[calc(100vh-4rem)] flex-col items-center justify-center space-y-4 text-center">
      <h1 className="text-4xl font-bold">Thank You!</h1>
      <p className="text-xl text-muted-foreground">Your message has been sent successfully.</p>
      <Button asChild>
        <Link href="/">Return Home</Link>
      </Button>
    </div>
  )
}

