import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, MapPin, Phone } from "lucide-react"
import Image from "next/image"
import { sendEmail } from "@/lib/actions"

export default function Contact() {
  return (
    <div className="container mx-auto py-12">
      <div className="grid gap-8 md:grid-cols-2">
        <Card className="relative overflow-hidden">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mardi_Himal1.jpg-batmVLOYcJgjNf4KWRfoJVhqr2uF1H.jpeg"
            alt="Mountain view"
            width={600}
            height={400}
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-background/20 p-6">
            <h2 className="mt-auto text-3xl font-bold text-white">Let's Connect</h2>
          </div>
        </Card>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon">
                  <Phone className="h-4 w-4" />
                </Button>
                <div>
                  <p className="font-medium">Phone</p>
                  <p className="text-sm text-muted-foreground">+977 9845952270</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon">
                  <Mail className="h-4 w-4" />
                </Button>
                <div>
                  <p className="font-medium">Email</p>
                  <p className="text-sm text-muted-foreground">paudelg98@gmail.com</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon">
                  <MapPin className="h-4 w-4" />
                </Button>
                <div>
                  <p className="font-medium">Location</p>
                  <p className="text-sm text-muted-foreground">Madi 05, Chitwan</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Get in Touch</CardTitle>
            </CardHeader>
            <CardContent>
              <form action={sendEmail}>
                <div className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Name
                      </label>
                      <Input id="name" name="name" required />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email
                      </label>
                      <Input id="email" name="email" type="email" required />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Message
                    </label>
                    <Textarea id="message" name="message" required />
                  </div>
                  <Button type="submit" className="w-full">
                    Send Message
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

