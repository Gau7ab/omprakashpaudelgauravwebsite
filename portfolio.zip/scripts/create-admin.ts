import { createAdminUser } from "../lib/auth"
import { db } from "../db"

async function main() {
  await createAdminUser("gaurab0a", "hbvsbc2000gg#")
  console.log("Admin user created successfully")
  await db.end()
}

main().catch(console.error)

