import { compare, hash } from "bcryptjs"
import { db } from "@/db"
import { users } from "@/db/schema"
import { eq } from "drizzle-orm"

export async function createAdminUser(username: string, password: string) {
  const hashedPassword = await hash(password, 12)
  await db.insert(users).values({ username, password: hashedPassword })
}

export async function verifyUser(username: string, password: string) {
  const user = await db.select().from(users).where(eq(users.username, username)).limit(1)
  if (user.length === 0) return null
  const isValid = await compare(password, user[0].password)
  if (!isValid) return null
  return user[0]
}

