"use server"

import { redirect } from "next/navigation"

export async function sendEmail(formData: FormData) {
  const name = formData.get("name")
  const email = formData.get("email")
  const message = formData.get("message")

  // Here you would typically use an email sending service
  // For this example, we'll just log the data
  console.log("Sending email:", { name, email, message })

  // In a real application, you'd send an email here
  // For example, using the Resend API:
  //
  // import { Resend } from 'resend'
  // const resend = new Resend(process.env.RESEND_API_KEY)
  // await resend.emails.send({
  //   from: 'onboarding@resend.dev',
  //   to: 'paudelg98@gmail.com',
  //   subject: 'New contact form submission',
  //   text: `Name: ${name}\nEmail: ${email}\nMessage: ${message}`,
  // })

  // Redirect to a thank you page
  redirect("/thank-you")
}

